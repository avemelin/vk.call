package com.example.vk_call;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import jp.wasabeef.blurry.Blurry;




public class MainActivity extends AppCompatActivity {
    ImageButton btn_lst;
    ImageButton btn_cam;
    ImageButton btn_hand;
    ImageButton btn_exit;
    ImageButton btn_sms;
    ImageButton btn_cnt;

    TextView you, max;
    ImageView viev_i, viev_Max;


    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        viev_i = (ImageView) findViewById(R.id.imageView9);
        viev_Max = (ImageView) findViewById(R.id.View_Max);
        if (hasFocus) {
            Blurry.with(this).sampling(10).capture(findViewById(R.id.imageView9)).into(viev_i);
            Blurry.with(this).sampling(10).capture(findViewById(R.id.View_Max)).into(viev_Max);

        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_cnt = (ImageButton) findViewById(R.id.imageButton14);
        btn_cnt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DEFAULT, ContactsContract.Contacts.CONTENT_URI);
                startActivity(intent);
            }
        });

        you = (TextView) findViewById(R.id.textView3);
        max = (TextView) findViewById(R.id.textView4);

        btn_sms = (ImageButton) findViewById(R.id.imageButton13);
        btn_sms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent smsIntent = new Intent(Intent.ACTION_SENDTO);
                smsIntent.addCategory(Intent.CATEGORY_DEFAULT);
                smsIntent.setType("vnd.android-dir/mms-sms");
                smsIntent.setData(Uri.parse("sms:"));
                startActivity(smsIntent);
            }

        });
        btn_lst = (ImageButton) findViewById(R.id.imageButton15);
        you = (TextView) findViewById(R.id.textView3);
            final boolean[] flag_lst = {true};
            you = (TextView) findViewById(R.id.textView3);
            max = (TextView) findViewById(R.id.textView4);
        btn_lst.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v)  {
                    if (flag_lst[0]) {
                        you.setText(R.string.Some);
                        max.setText(R.string.you);
                        flag_lst[0] = false;
                    }
                    else if (flag_lst[0] == false)
                    {
                        you.setText(R.string.you);
                        max.setText(R.string.Some);
                        flag_lst[0] = true;
                    }
                }
            });





        btn_exit = (ImageButton) findViewById(R.id.imageButton19);
        btn_exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finishAffinity();
                System.exit(0);
            }
        });
        final boolean[] flag_mic = {false};
        ImageButton btn_mic = (ImageButton) findViewById(R.id.imageButton17);
        btn_mic.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)  {
                if (flag_mic[0]) {
                    you.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.on_micro, 0);
                    btn_mic.setImageResource(R.drawable.on_micro);

                    btn_mic.setBackgroundResource(R.drawable.roundcorner);
                    flag_mic[0] = false;
                }
                else if (flag_mic[0] == false)
                {
                    you.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.woff_micro, 0);
                    btn_mic.setImageResource(R.drawable.off_micro);

                    btn_mic.setBackgroundResource(R.drawable.roundcorner_black);
                    flag_mic[0] = true;
                }
            }
        });

        final boolean[] flag_cam = {false};
        ImageButton btn_cam = (ImageButton) findViewById(R.id.imageButton16);
        btn_cam.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)  {
                if (flag_cam[0] == true) {
                    btn_cam.setImageResource(R.drawable.on_cam);
                    btn_cam.setBackgroundResource(R.drawable.roundcorner);
                    flag_cam[0] = false;
                }
                else if (flag_cam[0] == false)
                {
                    btn_cam.setBackgroundResource(R.drawable.roundcorner_black);
                    btn_cam.setImageResource(R.drawable.off_cam);
                    flag_cam[0] = true;
                }
            }
        });

        btn_hand = (ImageButton) findViewById(R.id.imageButton18);
        btn_hand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast toast = Toast.makeText( MainActivity.this,"Пожалуйста, прочитайте файл *Важно*", Toast.LENGTH_LONG );
                toast.setGravity(Gravity.TOP|Gravity.LEFT, 425, 1300);
                toast.show();
            }
        });

    }



}